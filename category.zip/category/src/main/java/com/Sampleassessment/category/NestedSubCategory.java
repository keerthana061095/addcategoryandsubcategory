package com.Sampleassessment.category;

import java.util.List;

public class NestedSubCategory {

	private String name;
	private List<String> value;
	
	

}
